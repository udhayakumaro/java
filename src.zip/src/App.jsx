import { useState } from "react";
import "./App.css";
import back from "./assets/image/back.png";
import laptop from "./assets/image/Laptop.png";
import RatingStar from "./component/RatinngStar";

function App() {
  return (
    <>
      <div className="app">
        <h1>Which Product would you like More,Please Rate it</h1>
        <div className="image">
          <div className="image1">
            <img src={back} alt="This is Phone" />
            <br></br>
            <RatingStar />
          </div>
          <div className="image2">
            <img src={laptop} alt="This is Laptop" />
            <br></br>
            <RatingStar />
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
